document.addEventListener("DOMContentLoaded", function() {
    // Gestion de l'affichage des sections
    const navLinks = document.querySelectorAll("header nav a");
    const sections = document.querySelectorAll("section");

    navLinks.forEach(link => {
        link.addEventListener("click", function(event) {
            event.preventDefault();

            // Masquer toutes les sections
            sections.forEach(section => {
                section.style.display = "none";
            });

            // Afficher la section correspondant au lien cliqué
            const targetSection = document.querySelector(this.getAttribute("href"));
            targetSection.style.display = "block";
        });
    });

    // Gestion du formulaire de contact
    document.getElementById("contactForm").addEventListener("submit", function(event) {
        event.preventDefault();
        let name = document.getElementById("name").value;
        let email = document.getElementById("email").value;
        let subject = document.getElementById("subject").value;
        let message = document.getElementById("message").value;

        if (name && email && subject && message) {
            document.getElementById("formMessage").textContent = "Votre demande a bien été envoyée. Merci!";
        } else {
            document.getElementById("formMessage").textContent = "Veuillez remplir tous les champs.";
        }
    });
});
